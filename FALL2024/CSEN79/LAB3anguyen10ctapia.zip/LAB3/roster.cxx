/*
 * CSEN 79 Lab Sample Code
 */
#include <string>
#include <iostream>
#include <stdexcept>
#include "roster.h"

namespace csen79 {
	static int idx = 0;
	
	Student::Student(ID_t temp, std::string fn, std::string ln){
		this->id = temp;
		this->firstName = fn;
		this->lastName = ln;
	}


	std::ostream& operator<<(std::ostream& os, const Student &t) {
		// your code here
		os << "ID:" << t.id << " " << "First Name: " << t.firstName << " " << "Last Name: " << t.lastName;
		return os;
	}

	// state your pre-/post-conditions

	bool Roster::insert(T &rec) {		

		for (int i = 0; i < size; ++i){
			if(students[i].getID() == rec.getID()){
				std::cout << "Student, " <<  rec.getFirstName() << " " <<  rec.getLastName() << " with ID: " << rec.getID() << " has a duplicate." << std::endl;
				return false;
			}
		}
		// your code here
		if (size < CAPACITY){
			// std::cout << "Roster is not full, student inserted" << std::endl;
			students[size++] = rec;		//increments size and adds student to array
			return true;
		}
		return false;					//returns false by default

		
	}

	// state your pre-/post-conditions
	// PreCondition: Roster cannot be empty
	// PostCondition: Program breaks when roster becomes empty
	void Roster::erase(Student::ID_t id) {
		for (int i = 0; i < size; ++i){
			if (students[i].getID() == id){
				for (int j = i; j < size - 1; ++j){
					students[j] = students[j+1];
				}
				std::cout << "Student, " << students[i].getFirstName() << " " << students[i].getLastName() << "with ID, " << students[i].getID() << " has been removed from the roster." << std::endl;
				--size;
				break;
			}
		}
	}

	// rudimentary iterator
	Roster::T* Roster::begin(void) {
		idx = 0;
		return students;
		// return nullptr;
	}

	Roster::T* Roster::end(void) {
		// return nullptr;
		// return &students[size-1];
		return students+size;
	}

	// The next element for interation
	Roster::T* Roster::next(void) {
		// return nullptr;
		if (idx < size-1 || idx <= CAPACITY){
			++idx;
			return &students[idx];
		}else{
			return nullptr;		//meaning end of roster is reached
		}
	}
}
