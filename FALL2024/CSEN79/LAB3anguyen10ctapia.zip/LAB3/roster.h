/*
 * CSEN 79 Lab Sample Code
 */
#ifndef ROSTER_H
#define ROSTER_H

// Class declaration for roster
namespace csen79 {
	// base data for the roster
	class Student {
	public:
		using ID_t = unsigned int;	// really should be a 7-digit unsigned int
		// Student(); 				Default constructor
		Student(ID_t n, std::string fn, std::string ln);
		friend std::ostream& operator<<(std::ostream& os, const Student &);

		ID_t getID() const {return id;};
		std::string getFirstName() const { return firstName; }
		std::string getLastName() const { return lastName; }

		Student() : id(0), firstName(""), lastName("") {}
	
	
	
	private:
		ID_t id;
		std::string firstName;
		std::string lastName;
	};

	class Roster {
	public:
		using T = Student;
		static const int CAPACITY=30;

		Roster() : size(0){} 		//Default Constructor

		bool insert(T &);
		void erase(Student::ID_t);

		T* begin(void);
		T* end(void);
		T* next(void);
		int getSize() const;
	private:
		T students[CAPACITY];
		int size;
		// int current;
	};
}
#endif // ROSTER_H
